from flask import Flask,render_template,request
import requests,json,http.client,sqlite3

app = Flask(__name__)
@app.route("/")
def index():
    return render_template("index.html",users=selectData())

@app.route('/register', methods=['POST'])
def register():
    payment = request.form.get('payment', 'Not set')
    fname = request.form.get('fname', 'Not set')
    ename = request.form.get('ename', 'Not set')
    address = request.form.get('address', 'Not set')
    zip_code = request.form.get('zip-code', 'Not set')
    city = request.form.get('city', 'Not set')
    cell = request.form.get('cell', 'Not set')
    mail = request.form.get('mail', 'Not set')
    passw = request.form.get('password', 'Not set')
    offers = request.form.get('offers', 'Not set')
    mail_format = request.form.get('mail-format', 'Not set')
    comments = request.form.get('comments', 'Not set')
    data_dict = {
        "payment": payment,
        "fname": fname,
        "ename": ename,
        "address": address,
        "zip_code": zip_code,
        "city": city,
        "cell": cell,
        "mail": mail,
        "passw": passw,
        "offers": offers,
        "mail_format": mail_format,
        "comments" : comments
             }

    r = requests.post('http://127.0.0.1:5000/postjson', json=data_dict)
    print(r.status_code)
    return index()

@app.route('/postjson', methods=['POST'])

def postJsonHandler():
    print(f'request.is_json: {request.is_json}')
    content=request.get_json()
    try:
        sqliteConnection = sqlite3.connect('uppgifter.db')
        cursor = sqliteConnection.cursor()
        print("Successfully Connected to SQLite")
        
        sqlite_insert_with_param = """INSERT INTO uppgifter
                            (payment,fname,ename,address,zip_code,city,cell,mail,passw,offers,mail_format,comments) 
                            VALUES (?,?,?,?,?,?,?,?,?,?,?,?);"""

        data_tuple = (content['payment'], content['fname'],content['ename'], 
                        content['address'], content['zip_code'],content['city'],
                        content['cell'],content['mail'], content['passw'],
                        content['offers'], content['mail_format'],content['comments'])

        cursor.execute(sqlite_insert_with_param, data_tuple)
        sqliteConnection.commit()
        # res = cursor.execute('select * from uppgifter')
        print("Record inserted successfully into SqliteDb_developers table ", cursor.rowcount)
        cursor.close()

    except sqlite3.Error as error:
        print("Failed to insert data into sqlite table", error)
    finally:
        if (sqliteConnection):
            sqliteConnection.close()
            print("The SQLite connection is closed")           
    return 'sucess'


def selectData():
    try:
        sqliteConnection = sqlite3.connect('uppgifter.db')
        cursor = sqliteConnection.cursor()
        res = cursor.execute('select * from uppgifter')
        data = res.fetchall()
        sqliteConnection.commit()
        cursor.close()
    except sqlite3.Error as error:
        print("Failed to insert data into sqlite table", error)
    finally:
        if (sqliteConnection):
            sqliteConnection.close()
            print("The SQLite connection is closed")           
    return data


if __name__ == "__main__":
    app.run(debug=True)
    #We made two new changes